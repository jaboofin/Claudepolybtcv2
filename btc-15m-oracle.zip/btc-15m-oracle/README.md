<div align="center">

# ₿ BTC-15M-Oracle

**Autonomous BTC prediction bot for Polymarket**

Clock-synced · 4-signal strategy · Live CLOB execution · Arb & hedge engines

```
python bot.py --bankroll 500 --arb --hedge
```

</div>

---

## What This Does

Every 15 minutes, Polymarket runs a binary market: *"Will BTC go up or down?"*

This bot trades those markets autonomously. It wakes up 60 seconds before each window, analyzes BTC using four technical signals across three price oracles, places a real signed order via Polymarket's CLOB, then goes back to sleep. Rinse and repeat, 96 times a day.

It also has two optional edge engines — an **arbitrage scanner** that catches mispricings between the UP and DOWN sides, and a **hedge module** that protects open positions when the signal flips.

---

## Quickstart

**1. Install dependencies**

```bash
pip install -r requirements.txt
```

**2. Export your Polymarket wallet keys**

Go to [reveal.polymarket.com](https://reveal.polymarket.com) to get your private key, then grab your deposit address from Polymarket's deposit page.

```bash
export POLY_PRIVATE_KEY="your_private_key"
export POLY_FUNDER="0xYourDepositAddress"
export POLY_SIG_TYPE=1
```

> **SIG_TYPE:** `1` = email/Magic login (most common), `2` = browser wallet (MetaMask), `0` = direct EOA

**3. Run**

```bash
python bot.py --bankroll 100
```

The bot is now live, placing real orders with a $100 bankroll. Every 15 minutes it wakes, decides, trades, sleeps.

---

## How It Works

### Timing

The bot is **clock-synced** — it doesn't poll randomly. It calculates the exact second to fire before each 15-minute boundary:

```
11:59:00  →  analyze + trade    (targeting 12:00 boundary)
12:14:00  →  analyze + trade    (targeting 12:15 boundary)
12:29:00  →  analyze + trade    (targeting 12:30 boundary)
12:44:00  →  analyze + trade    (targeting 12:45 boundary)
```

Between windows it polls the clock every 5 seconds. No wasted API calls, no drift.

### Pipeline (each cycle)

```
Oracle ─→ Strategy ─→ Risk Check ─→ Market Discovery ─→ [Arb] ─→ [Hedge] ─→ Execute ─→ Resolve
```

**Oracle** — Fetches BTC/USD from Binance, CoinGecko, and CoinCap simultaneously. Takes the median. Rejects stale prices (>30s) and flags divergence >1%.

**Strategy** — Runs four weighted technical signals across 100 recent 15-minute candles:

| Signal | Weight | Logic |
|--------|--------|-------|
| Momentum | 30% | Price delta over N candles — raw directional pressure |
| RSI | 25% | 14-period Wilder's — detects overbought/oversold extremes |
| MACD | 25% | 12/26/9 crossover — trend momentum + histogram strength |
| EMA Cross | 20% | Fast(5) / Slow(15) crossover — short-term trend shift |

Outputs a direction (UP/DOWN/HOLD) and a confidence score from 0 to 1. Only trades when confidence ≥ 60%.

**Risk** — Enforces daily trade cap (20), daily loss limit (15%), consecutive loss cooldown (5 losses → 60min pause), and position sizing via quarter-Kelly criterion.

**Execution** — Uses `py-clob-client` SDK to place an EIP-712 signed market order (fill-or-kill) directly on Polymarket's Central Limit Order Book. Parses the response for actual fill price and transaction hashes.

---

## CLI Reference

```bash
python bot.py --bankroll 500                # Run with $500, 24/7
python bot.py --bankroll 100 --cycles 10    # Run 10 windows then stop
python bot.py --bankroll 200 --arb          # Enable arbitrage scanner
python bot.py --bankroll 200 --hedge        # Enable hedge engine
python bot.py --bankroll 500 --arb --hedge  # Everything on
```

| Flag | Default | Description |
|------|---------|-------------|
| `--bankroll` | 500 | Starting capital in USD |
| `--cycles` | 0 | Max entry windows (0 = run forever) |
| `--arb` | off | Enable arbitrage scanner |
| `--hedge` | off | Enable hedge engine |

**Ctrl+C** → graceful shutdown. Saves performance snapshot, cancels pending orders, closes connections.

---

## Edge Engines

Both off by default. Toggle them with CLI flags.

### Arbitrage (`--arb`)

Every cycle, the arb scanner checks all active BTC 15-min markets for mispricing. On Polymarket, UP + DOWN should sum to ~$1.00. When they don't, it's free money:

```
UP = $0.45  ·  DOWN = $0.48  ·  total = $0.93
Buy both sides → one always resolves to $1.00
Profit = $0.07 per share (7.5%) — zero risk
```

These gaps are rare on liquid markets but they appear on fast-moving 15-minute windows. The scanner catches them automatically.

| Setting | Default | What it controls |
|---------|---------|-----------------|
| `arb_threshold` | 0.98 | Only arb if UP + DOWN < this |
| `arb_min_edge_pct` | 1.0% | Ignore edges smaller than this |
| `arb_size_usd` | $10 | How much to bet per side |

### Hedge (`--hedge`)

Tracks your open positions. If the strategy flips direction while you're holding, the hedge engine buys the opposite side to lock in a guaranteed outcome:

```
Holding UP @ $0.55 → strategy flips to DOWN (confidence 0.70)
Buy DOWN @ $0.40 → total exposure = $0.95
One side pays $1.00 → locked profit = $0.05 per share
```

If the combined cost exceeds $1.00, the hedge still caps your downside — you lose less than riding out an unhedged position.

| Setting | Default | What it controls |
|---------|---------|-----------------|
| `hedge_min_confidence` | 0.65 | Only hedge if the flip signal is this strong |

---

## Wallet Setup

### Polymarket Email Login *(most users)*

This is the standard Polymarket wallet. No MetaMask needed.

1. Log in at [polymarket.com](https://polymarket.com) with your email
2. Go to **Deposit** → copy your **Deposit Address** → this is `POLY_FUNDER`
3. Go to [reveal.polymarket.com](https://reveal.polymarket.com) → export your key → this is `POLY_PRIVATE_KEY`
4. Set `POLY_SIG_TYPE=1`
5. Make sure your wallet has USDC on Polygon

### Browser Wallet (MetaMask, Coinbase Wallet)

1. Connect your wallet to Polymarket
2. Export your Polygon private key → `POLY_PRIVATE_KEY`
3. Copy your Polymarket proxy address → `POLY_FUNDER`
4. Set `POLY_SIG_TYPE=2`
5. Approve token allowances first (USDC + CTF on Polygon)

### Direct EOA

1. Use any Polygon private key → `POLY_PRIVATE_KEY`
2. No funder needed
3. Set `POLY_SIG_TYPE=0`

---

## Configuration

All tuning parameters live in `config/settings.py`. The defaults are conservative.

### Timing

| Param | Default | What it does |
|-------|---------|-------------|
| `entry_lead_secs` | 60 | How early before the boundary to fire |
| `entry_window_secs` | 30 | How long the entry window stays open |
| `sleep_poll_secs` | 5 | Clock check interval while idle |

### Strategy

| Param | Default | What it does |
|-------|---------|-------------|
| `confidence_threshold` | 0.60 | Minimum score to trade (0–1) |
| `weight_momentum` | 0.30 | Momentum signal weight |
| `weight_rsi` | 0.25 | RSI signal weight |
| `weight_macd` | 0.25 | MACD signal weight |
| `weight_ema_cross` | 0.20 | EMA crossover weight |

### Risk

| Param | Default | What it does |
|-------|---------|-------------|
| `max_trade_size_usd` | $25 | Hard cap per trade |
| `max_daily_trades` | 20 | Trades per day before stopping |
| `max_daily_loss_pct` | 15% | Daily drawdown circuit breaker |
| `max_consecutive_losses` | 5 | Triggers 60-minute cooldown |
| `kelly_fraction` | 0.25 | Quarter-Kelly position sizing |

### Orders

| Param | Default | What it does |
|-------|---------|-------------|
| `order_type` | "market" | `"market"` (FOK) or `"limit"` (GTC) |
| `max_slippage_pct` | 2.0% | Max slippage before rejecting |
| `min_liquidity_usd` | $50 | Skip markets below this liquidity |

---

## Project Structure

```
btc-15m-oracle/
├── bot.py                        Main orchestrator — clock sync, CLI, trading loop
├── dashboard.jsx                 React dashboard (cyberpunk stream overlay)
│
├── config/
│   └── settings.py               All parameters — strategy, risk, timing, edge
│
├── core/
│   ├── polymarket_client.py      py-clob-client SDK — order signing + execution
│   ├── risk_manager.py           Kelly sizing, daily limits, loss cooldowns
│   ├── edge.py                   Arbitrage scanner + hedge engine
│   └── trade_logger.py           Structured JSONL logging
│
├── oracles/
│   └── price_feed.py             3-source BTC price consensus engine
│
├── strategies/
│   └── signal_engine.py          4-signal weighted technical strategy
│
├── logs/                         Runtime logs (trades, strategy, oracle, errors)
├── data/                         Performance snapshots
├── .env.example                  Wallet config template
└── requirements.txt              Python dependencies
```

---

## Logs

Every action is logged to structured JSONL for full auditability:

| File | What's in it |
|------|-------------|
| `logs/trades.jsonl` | Every order placed — direction, size, fill price, order ID, tx hashes |
| `logs/strategy.jsonl` | Every decision — signal values, confidence, direction, hold reasons |
| `logs/oracle.jsonl` | Every price fetch — source prices, consensus, spread |
| `logs/errors.log` | Errors with stack traces |
| `data/performance.json` | Latest cumulative stats snapshot |

---

## Safety

The bot has multiple layers of protection to prevent catastrophic losses:

**Market restriction** — Hardcoded to BTC 15-minute UP/DOWN binary markets only. It will never trade any other asset or market type.

**Oracle consensus** — Requires 2/3 price sources to agree. Rejects stale data (>30s old). Alerts when source spread exceeds 1%.

**Daily circuit breaker** — If cumulative daily losses exceed 15% of your bankroll, the bot stops trading for the rest of the day.

**Loss streak cooldown** — After 5 consecutive losses, the bot pauses for 60 minutes before resuming.

**Conservative sizing** — Quarter-Kelly criterion with a hard $25 cap per trade. Even at maximum confidence, a single trade won't exceed 5% of capital.

**No keys, no trades** — The CLOB client won't initialize without a valid `POLY_PRIVATE_KEY`. There's no way to accidentally execute orders.

**Full audit trail** — Every oracle query, strategy decision, risk check, and trade execution is logged to JSONL with timestamps. Nothing happens off the record.

---

## Dependencies

```
aiohttp>=3.9.0           Async HTTP for oracle + Gamma API
py-clob-client>=0.34.0   Polymarket CLOB SDK — order signing + execution
web3==6.14.0              Ethereum interaction (pinned to avoid eth-typing conflicts)
python-dotenv>=1.0.0      Environment variable loading
```

---

## Dashboard

The included `dashboard.jsx` is a React component designed as a stream overlay. Dark cyberpunk aesthetic — readable at 720p/1080p. Shows live positions (open + closed), equity curve, signal meters, arb/hedge toggle status, countdown to next entry, and bankroll tracking.

Drop it into any React project or render it as an artifact.

---

## Disclaimer

This bot places real orders with real money on Polymarket prediction markets. Start with a small bankroll you're comfortable losing. Cryptocurrency markets are volatile and prediction markets carry additional risks. Past backtest performance does not guarantee future results. The authors assume no liability for financial losses.
